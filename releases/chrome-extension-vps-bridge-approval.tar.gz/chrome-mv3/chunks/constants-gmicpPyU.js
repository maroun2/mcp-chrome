const NATIVE_HOST = {
  DEFAULT_PORT: 12306
};
const BRIDGE_SERVER = {
  DEFAULT_URL: "ws://127.0.0.1:12306"
};
const LINKS = {
  TROUBLESHOOTING: "https://github.com/hangwin/mcp-chrome/blob/master/docs/TROUBLESHOOTING.md"
};
const STORAGE_KEYS = {
  SERVER_STATUS: "serverStatus",
  NATIVE_SERVER_PORT: "nativeServerPort",
  BRIDGE_SERVER_URL: "bridgeServerUrl",
  BRIDGE_TOKEN: "bridgeToken",
  NATIVE_AUTO_CONNECT_ENABLED: "nativeAutoConnectEnabled",
  SEMANTIC_MODEL: "selectedModel",
  USER_PREFERENCES: "userPreferences",
  VECTOR_INDEX: "vectorIndex",
  USERSCRIPTS: "userscripts",
  USERSCRIPTS_DISABLED: "userscripts_disabled",
  // Record & Replay storage keys
  RR_FLOWS: "rr_flows",
  RR_RUNS: "rr_runs",
  RR_PUBLISHED: "rr_published_flows",
  RR_SCHEDULES: "rr_schedules",
  RR_TRIGGERS: "rr_triggers",
  // Persistent recording state (guards resume across navigations/service worker restarts)
  RR_RECORDING_STATE: "rr_recording_state"
};
export {
  BRIDGE_SERVER as B,
  LINKS as L,
  NATIVE_HOST as N,
  STORAGE_KEYS as S
};
